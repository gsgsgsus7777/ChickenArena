ЭТО ИСХОДНЫЙ ПРОЕКТ, НЕ APK.
Загрузи ВСЁ содержимое ZIP в новый GitHub-репозиторий.
Открой Actions → Build Android APK → Run workflow.
После завершения скачай artifact ChickenArena-debug-apk.
Распакуй artifact ZIP и установи app-debug.apk.
Для загрузки 3D-сцены при первом запуске нужен интернет.
